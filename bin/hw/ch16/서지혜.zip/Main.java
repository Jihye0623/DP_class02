package hw.ch16;

public class Main {
    public static void main(String[] args) {
        new LoginFrame("20210694 서지혜");
    }
}
