package hw.ch15;

import hw.ch15.pagemaker.PageMaker;

public class Main {
    public static void main(String[] args) {
        PageMaker.makeUrlPage("urlPage.html");
    }
}
