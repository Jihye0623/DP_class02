package hw.ch05.framework;

public abstract class Product {
    public abstract void use();
}
