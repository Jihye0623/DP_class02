package hw.ch22.command;

public interface Command {
    public abstract void execute();
}
